/************
* Michael Adejo 
* Lab 1 
* January 21, 2024 
* A program that performs basic Operations
**/

package HelloWorld;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				System.out.print("HelloWorld! \n");
				
				//Declaring variables x and y 
				int x = 26;
				int y = 5;
				
				//adding x and y 
				System.out.println("x + y = " + (x+y));
				//subtracting y from x 
				System.out.println("x - y = " + (x-y));
				//subtracting x from y 
				System.out.println("y - x = " + (y-x));
				//dividing x by y 
				System.out.println("x / y = " + (x/y));
			
				//Declaring variables a and b
				double a = 26.0;
				double b = 5.0;
				
				//adding a and b
				System.out.println("a + b = " + (a+b));
				//subtracting b from a
				System.out.println("a - b = " + (a-b));
				//subtracting a from b
				System.out.println("b - a = " + (b-a));
				//dividing a by b
				System.out.println("a / b = " + (a/b));
				
	}

}
