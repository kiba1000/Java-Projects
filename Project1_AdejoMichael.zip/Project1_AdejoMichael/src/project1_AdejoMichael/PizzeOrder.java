/************
* Michael Adejo 
* Project 1 
* Febuary 18, 2024 
* A pizza ordering program 
**/
package project1_AdejoMichael;

import java.util.Scanner;

public class PizzeOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Declaring variables
		Scanner keyboardInput = new Scanner(System.in);
		String firstname;
		boolean discount = false;
		int inches;
		char crustType;
		String crust = "Hand-tossed";
		double cost = 12.99;
		final double TAX_RATE = 0.08;
		double tax;
		char choice;
		String input;
		String toppings = "Cheese";
		int numberOfToppings = 0;
				
		//Displaying a Welcome banner
		System.out.print("*******************************************" + "\n");
		System.out.print("*                                         *" + "\n");
		System.out.print("*         Welcome to Planet Pizza         *" + "\n");
		System.out.print("*                                         *" + "\n");
		System.out.print("*******************************************" + "\n");
		
		// Prompting the user for the first name
		System.out.print("Enter your first name: "+"\n");
		firstname = keyboardInput.next();
		
		//Condition for the discount
		if (firstname.equals("Andy") || firstname.equals("andy")) {
			discount = true;	
		}
		
		//Displaying the pizza size and cost list
		System.out.println("Pizza Size(inches) - Cost");
		
		System.out.println("10in  ->  $10.99"+ "\n" + "12in  ->  $12.99");
		
		System.out.println("14in  ->  $14.99"+ "\n" + "16in  ->  $16.99"+"\n");
		
		//Prompting the user to select a size
		System.out.println("SELECT A SIZE:");	
		inches = keyboardInput.nextInt();
		
		//Conditions(if statement) for the size inputed
		if (inches == 10) {
			cost = 10.99;
			System.out.println(firstname + " --> $" + cost + "\n");
		}
		else if (inches == 12) {
			System.out.println(firstname + " --> $" + cost + "\n");
		}
		else if (inches == 14) {
			cost = 14.99;
			System.out.println(firstname + " --> $" + cost + "\n");
		}
		else if (inches == 16) {
			cost = 16.99;
			System.out.println(firstname + " --> $" + cost + "\n");
		}
		else {
			System.out.print("Input was not one of the choices, so a 12 inch pizza will be made." + "\n");
			System.out.println(firstname + " --> $" + cost +"\n");
		}
		
		//Prompting the user to select a crust-type
		System.out.print("What type of crust do you want?"+"\n");
		System.out.println("(H)Hand-tossed" + "\n"+ "(T)Thin-crust"+"\n"+"(D)Deep-dish" + "\n");
		
		crust = keyboardInput.next();
		
		//Conditions(switch staement) for the crust inputed
		switch (crust) 
		{
			case "Hand-tossed","hand-tossed", "h", "H":
				crust = "Hand-tossed";
				crustType = 'H';
				break;
				
			case "Deep-dish","deep-dish", "d", "D":
				crust= "Deep-dish";
				crustType = 'D';
				break;
				
			case "Thin-crust","thin-crust", "t", "T":
				crust = "Thin-crust";
				crustType = 'T';
				break;
			default:
				System.out.print ("Input was not one of the choices, so a Hand-tossed crust will be made.");			
				crust = "Hand-tossed";
				crustType = 'H';
		}
		
		//condition for each topping the user selects
		System.out.println("All pizzas come with cheese.\r\n"
				+ "Additional toppings are $1.25 each,\r\n"
				+ "choose from Pepperoni, Sausage, Onion, Mushroom." + "\n");
		
		System.out.println("Do you want Pepperoni? (Y/N):");
		input = keyboardInput.next();
		
		if (input.equals("Y")|| input.equals("y")|| input.equals("yes")|| input.equals("Yes")) {
			numberOfToppings += 1;
			toppings = toppings + ", Pepperoni";
			cost += 1.25;	 
		}
		System.out.println("Do you want Sausage? (Y/N):");
		input = keyboardInput.next();
		
		if (input.equals("Y")|| input.equals("y")|| input.equals("yes")|| input.equals("Yes")) {
			numberOfToppings += 1;
			toppings = toppings + ", Sausage";
			cost += 1.25;
		}
		System.out.println("Do you want Onion? (Y/N):");
		input = keyboardInput.next();
		
		if (input.equals("Y")|| input.equals("y")|| input.equals("yes")|| input.equals("Yes")) {
			numberOfToppings += 1;
			toppings = toppings + ", Onion";
			cost += 1.25;	 
		}
		System.out.println("Do you want Mushroom? (Y/N):");
		input = keyboardInput.next();
		
		if (input.equals("Y")|| input.equals("y")|| input.equals("yes")|| input.equals("Yes")) {
			numberOfToppings += 1;
			toppings = toppings + ", Mushroom";
			cost += 1.25;	 
		}
		
		//Determining the final cost based on the user's select delivery option , applicable tax rate, and discount eligibility
		boolean deliveryChoice = false;
		double deliveryFee = 0.0;
		
		System.out.println("Do you want delivery or carry-out (D/C):");
		
		choice = keyboardInput.next().charAt(0);
		
		if (choice == 'D' || choice == 'd') {
			deliveryChoice = true;
			deliveryFee = (Math.floor(Math. random() *(25 - 1 + 1) + 1)) * 0.5;
			cost = cost + deliveryFee;	
		}
		
		if (discount == true) {
			cost = cost - (cost* 0.1); 
		}
		
		tax = cost * TAX_RATE;
		cost = cost + tax;
		
		// convertng the cost to 2 decimal places
		String newCost = String.format("%.2f", cost);
		
		//Printing the user's order summary
		System.out.println("Your order is as follows: ");
		System.out.println(inches + " inch pizza");
		System.out.println(crust + " crust");
		System.out.println(toppings + "\n");
		
		//Print the user's total cost
		System.out.println(firstname + ", the total cost of your pizza is " + newCost);


		keyboardInput.close();
	}

}
