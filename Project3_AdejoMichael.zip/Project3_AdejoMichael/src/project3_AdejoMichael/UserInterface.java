package project3_AdejoMichael;

import javax.swing.JOptionPane;

public class UserInterface {
    public String getUserName() {
        return JOptionPane.showInputDialog("Enter your name:");
    }

    public Pizza getUserOrder() {
        int size = Integer.parseInt(JOptionPane.showInputDialog("Enter pizza size (8, 12, or 16):"));
        String crust = JOptionPane.showInputDialog("Enter crust type (Hand Tossed, Thin, or Stuffed):");
        String toppingsInput = JOptionPane.showInputDialog("Enter toppings separated by commas:");
        String[] toppings = toppingsInput.split(",");

        // Trim whitespace from toppings
        for (int i = 0; i < toppings.length; i++) {
            toppings[i] = toppings[i].trim();
        }

        return new Pizza(size, toppings, crust);
    }

    public void userPrompt(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}