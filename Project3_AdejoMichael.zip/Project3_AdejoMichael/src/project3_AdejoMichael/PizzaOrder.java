package project3_AdejoMichael;

import java.io.PrintWriter;

public class PizzaOrder {
    private String userName;
    private UserInterface gui;
    private Pizza[] order;
    private double cost;

    public static void main(String[] args) {
        PizzaOrder pizzaOrder = new PizzaOrder();
        pizzaOrder.getUserName();
        pizzaOrder.getOrder();
        pizzaOrder.computeCost();
        pizzaOrder.printReceipt();
    }

    public PizzaOrder() {
        gui = new UserInterface();
        order = new Pizza[0]; // Initialize with an empty array
    }

    private void getUserName() {
        userName = gui.getUserName();
    }

    private void getOrder() {
        Pizza pizza;
        do {
            pizza = gui.getUserOrder();
            if (pizza != null) {
                order = addPizzaToOrder(order, pizza);
            }
        } while (pizza != null);
    }

    private Pizza[] addPizzaToOrder(Pizza[] currentOrder, Pizza pizza) {
        Pizza[] newOrder = new Pizza[currentOrder.length + 1];
        System.arraycopy(currentOrder, 0, newOrder, 0, currentOrder.length);
        newOrder[newOrder.length - 1] = pizza;
        return newOrder;
    }

    private void computeCost() {
        cost = computeSpecials();
        for (Pizza pizza : order) {
            cost += pizza.getPizzaSize(); // Assuming getPizzaSize() returns the cost
        }
    }

    private double computeSpecials() {
        // Example: 10% discount if the order includes 3 or more pizzas
        double discount = (order.length >= 3) ? 0.9 : 1.0; // 10% discount if 3 or more pizzas
        double specialCost = 0.0;
        for (Pizza pizza : order) {
            specialCost += pizza.getPizzaSize() * discount;
        }
        return specialCost;
    }

    private void printReceipt() {
        try {
            PrintWriter writer = new PrintWriter("receipt.txt");
            writer.println("Customer: " + userName);
            writer.println("Order:");
            for (Pizza pizza : order) {
                writer.println(pizza.toString());
            }
            writer.println("Total Cost: $" + cost);
            writer.close();
        } catch (java.io.FileNotFoundException e) {
            System.out.println("Error creating receipt file: " + e.getMessage());
        }
    }
}
