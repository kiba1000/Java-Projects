package project3_AdejoMichael;

public class Pizza {
    private int pizzaSize;
    private String pizzaCrust;
    private String[] pizzaToppings;

    public Pizza() {
        this(12, new String[]{"Cheese"}, "Hand Tossed");
    }

    public Pizza(int size, String[] toppings, String crust) {
        pizzaSize = size;
        pizzaToppings = toppings.clone(); // Clone the array to avoid unintended modifications
        pizzaCrust = crust;
    }

    public void setPizzaSize(int size) {
        pizzaSize = size;
    }

    public void setPizzaToppings(String[] toppings) {
        pizzaToppings = toppings.clone(); // Clone the array to avoid unintended modifications
    }

    public void setPizzaCrust(String crust) {
        pizzaCrust = crust;
    }

    public int getPizzaSize() {
        return pizzaSize;
    }

    public String[] getPizzaToppings() {
        return pizzaToppings.clone(); // Clone the array to avoid returning the internal reference
    }

    public String getPizzaCrust() {
        return pizzaCrust;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(pizzaSize).append("\" ").append(pizzaCrust).append("\n");
        for (int i = 0; i < pizzaToppings.length; i++) {
            sb.append(pizzaToppings[i]);
            if (i < pizzaToppings.length - 1) {
                sb.append(", ");
            }
        }
        return sb.toString();
    }
}