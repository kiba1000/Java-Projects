/************
* Michael Adejo 
* Project 2 
* March 24, 2024 
* A pizza ordering program (GUI)
**/
package project2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class PizzaOrderGUI {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		
		//Declaring variables
		String firstname;
		String inches;
		char crustType;
		String crust ;
		double cost = 12.99;
		final double SALES_TAX = 0.07;
		double tax;
		String toppings ;
		String list = "Chesse";
		int numberOfToppings = 0;
		
		//Displaying a Welcome Dialog box
		JOptionPane.showMessageDialog(null,"Welcome to Pizza Planet!", "Welcome", JOptionPane.INFORMATION_MESSAGE);
		
		// Prompting the user for the first name
		firstname = JOptionPane.showInputDialog("Enter your first name:");
		
		
		while (true) {
		//Displaying the pizza size and cost list
		String sizeOption = "Pizza Size(inches) - Cost\n" +
                "10  -  $10.99\n" +
                "12  -  $12.99\n" +
                "14  -  $14.99\n" +
                "16  -  $16.99\n";
		JOptionPane.showMessageDialog(null, sizeOption, "Pizza Size and Cost", JOptionPane.INFORMATION_MESSAGE);
		
		//Prompting the user to select a size
		inches = JOptionPane.showInputDialog("SELECT A SIZE:");
		
		//Conditions for the size inputed
		switch (inches) {
        case "10":
            cost = 10.99;
            break;
        case "12":
            cost = 12.99;
            break;
        case "14":
            cost = 14.99;
            break;
        case "16":
            cost = 16.99;
            break;
        default:
            JOptionPane.showMessageDialog(null, "Your input does not match any of the available Size options. Please try again.", "ERROR", JOptionPane.ERROR_MESSAGE);
            continue;
		
		}
		break;
	}
		while(true) {
		//Prompting the user to select a crust-type	
		String crustOption = "PIZZA CRUST OPTIONS? \n" +
                "(H)Hand-tossed \n" + "(T)Thin-crust \n" + "(D)Deep-dish";
		JOptionPane.showMessageDialog(null, crustOption, "CRUST SELECTION", JOptionPane.INFORMATION_MESSAGE);
		
		crust = JOptionPane.showInputDialog("What type of crust do you want?");
		
		//Conditions(switch staement) for the crust inputed
		switch (crust) 
		{
			case "Hand-tossed","hand-tossed", "h", "H":
				crust = "Hand-tossed";
				crustType = 'H';
				break;
				
			case "Deep-dish","deep-dish", "d", "D":
				crust= "Deep-dish";
				crustType = 'D';
				break;
				
			case "Thin-crust","thin-crust", "t", "T":
				crust = "Thin-crust";
				crustType = 'T';
				break;
			default:
				JOptionPane.showMessageDialog(null, "Your input does not match any of the available Crust Options. Please try again.", "ERROR", JOptionPane.ERROR_MESSAGE);
				continue;
		}
		break;
		}
		//condition for each topping the user selects
		while(true) {
			toppings = JOptionPane.showInputDialog("Which toppings do you want? Type \"done\" if you are done. \n" + " - (P)Pepperoni \n - (S)Sausage \n - (O)Onion \n - (M)Mushroom " ) ;
			if (toppings.equals ("done")||toppings.equals("Done")) {
				break;
			}
			else if (toppings.equals ("P")||toppings.equals("p")||toppings.equals ("pepporoni")||toppings.equals("Pepporoni")) {
				toppings = "Pepporoni";
				list = list + ", " + toppings;
			 	numberOfToppings += 1;
			 	cost += 1.25;
			}
			else if (toppings.equals ("S")||toppings.equals("s")||toppings.equals ("sausage")||toppings.equals("Sausage")) {
				toppings = "Sausage";
				list = list + ", " + toppings;
				numberOfToppings += 1;
				cost += 1.25;
				}
			else if (toppings.equals ("O")||toppings.equals("o")||toppings.equals ("onion")||toppings.equals("Onion")) {
				toppings = "Onion";
				list = list + ", " + toppings;
				numberOfToppings += 1;
				cost += 1.25;
				}
			else if (toppings.equals ("M")||toppings.equals("m")||toppings.equals ("mushroom")||toppings.equals("Mushroom")) {
				toppings = "Mushroom";
				list = list + ", " + toppings;
				numberOfToppings += 1;
				cost += 1.25;
				}
			else {
				JOptionPane.showMessageDialog(null, "Your input does not match any of the available Toppings options. Please try again.", "ERROR", JOptionPane.ERROR_MESSAGE);
	            continue;
			}
		}
		
		tax = cost * SALES_TAX;
		cost = cost + tax;
		// convertng the cost to 2 decimal places
		String newCost = String.format("%.2f", cost);
		
		//Printing the user's order receipt
		PrintWriter receiptWriter = new PrintWriter(new FileWriter("pizza_receipt.txt"));
		
		receiptWriter.println("Customer Name: " + firstname +"\n");
		receiptWriter.println("=============================");
        receiptWriter.println("Your order is as follows:");
        receiptWriter.println("SIZE: " + inches + " inch pizza");
        receiptWriter.println("CRUST_TYPE: " +crust + " crust");
        receiptWriter.println("TOPPINGS: " + list);
        receiptWriter.println("=============================");
        
        receiptWriter.println("Total Price: $" + newCost);
        
 
        // Closing the writer
        receiptWriter.close();
		
}
}
