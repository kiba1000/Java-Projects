/************
* Michael Adejo 
* Lab 03 
* Febuary 04, 2024 
* A pizza ordering program that gets the cost of the pizza
**/
package Lab03_AdejoMichael;

import java.util.Scanner;

public class PizzeOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Declaring variables
		Scanner keyboardInput = new Scanner(System.in);
		String firstname;
		boolean discount = false;
		int inches;
		char crustType;
		String crust = "Hand-tossed";
		double cost = 12.99;
		final double TAX_RATE = 0.8;
		double tax;
		char choice;
		String input;
		String toppings = "Cheese";
		int numberOfToppings = 0;
				
		//Displaying a Welcome banner
		System.out.print("*******************************************" + "\n");
		System.out.print("*                                         *" + "\n");
		System.out.print("*         Welcome to Planet Pizza         *" + "\n");
		System.out.print("*                                         *" + "\n");
		System.out.print("*******************************************" + "\n");
		
		// Prompting the user for the first name 
		System.out.print("Enter your first name: "+"\n");
		firstname = keyboardInput.next();
		
		//Condition for the discount
		if (firstname.equals("Andy") || firstname.equals("andy")) {
			discount = true;	
		}
		
		//Displaying the pizza size and cost list
		System.out.println("Pizza Size(inches) - Cost");
		
		System.out.println("10in  ->  $10.99"+ "\n" + "12in  ->  $12.99");
		
		System.out.println("14in  ->  $14.99"+ "\n" + "16in  ->  $16.99"+"\n");
		
		//Prompting the user to select a size
		System.out.println("SELECT A SIZE:");	
		inches = keyboardInput.nextInt();
		
		//Conditions for the size inputed
		if (inches == 10) {
			cost = 10.99;
			System.out.println(firstname + ",the total cost of your pizza is $" + cost);
		}
		else if (inches == 12) {
			System.out.println(firstname + ",the total cost of your pizza is $" + cost);
		}
		else if (inches == 14) {
			cost = 14.99;
			System.out.println(firstname + ",the total cost of your pizza is $" + cost);
		}
		else if (inches == 16) {
			cost = 16.99;
			System.out.println(firstname + ",the total cost of your pizza is $" + cost);
		}
		else {
			System.out.print("Select a valid choice in the list provided");
		}
		keyboardInput.close();
	}

}
