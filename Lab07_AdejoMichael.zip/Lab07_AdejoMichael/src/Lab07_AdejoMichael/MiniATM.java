
/************
* Michael Adejo 
* Lab 07 
* March 03, 2024 
* A Mini Atm simulation
**/
package Lab07_AdejoMichael;

import javax.swing.JOptionPane;
import java.io.*;
import java.util.Scanner;

public class MiniATM {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		//Declaring requires variables
		int acc_num = 1234567;
		int acc_pin = 1234;
		double acc_balance = 100.00;
		int Num;
		double End_balance = 0;
		int lastFourDigits;
		
		// Prompting the user for the account number
		while (true) {
			
			String Num_input = JOptionPane.showInputDialog("ENTER YOUR ACCOUNT NUMBER:");
			Num = Integer.parseInt(Num_input);
		
			//verifying the input number is equal to the 7-digit given account number (1234567)
			if (hasEqualLength(Num, acc_num)){
				break;
			}
			else {
			JOptionPane.showMessageDialog(null,"PLEASE ENTER A VALID ACCOUNT NUMBER","ERROR", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		//Prompting the user for the account in
		while (true) {
			
			String Pin_input = JOptionPane.showInputDialog("ENTER YOUR PIN:");
			int Pin = Integer.parseInt(Pin_input);
		
			//verifying the input pin is equal to the 4-digit given account pin (1234)
			if (hasEqualLength(Pin, acc_pin)){
				break;
			}
			else {
			JOptionPane.showMessageDialog(null,"PLEASE ENTER A VALID PIN","ERROR", JOptionPane.ERROR_MESSAGE);
			}
		}
		
		// getting the last 4-digits of the account number
		lastFourDigits = Num % 10000;
		
		//Asking if the user would like to proceed
		int choice = JOptionPane.showOptionDialog(null, "Do you wish to proceed with the transaction? If not, your account balance will be shown.", "Question", 
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
	
		if(choice == JOptionPane.NO_OPTION) {
			
	        // Writing to the file
	        PrintWriter writer = new PrintWriter(new FileWriter("balance.txt"));

	        // Writing last four digits and account balance to the file
	        writer.println("Welcome to MiniATM!\n\n");
	        writer.println("Account Number (last 4): " + lastFourDigits+ "\n\n");
	        writer.println("Account Balance: $" + acc_balance);

	        // Closing the writer 
	        writer.close();
	        
	        return ;
		}
		
		
		boolean userDone = false;
		String close;
		
		//Prompting the user to select a transaction type 
		do {
			String transaction = JOptionPane.showInputDialog("Would you like to WITHDRAW or DEPOSIT money today (W/D) : ");
			
			switch (transaction) {
			case "w","W":
				String withdraw = JOptionPane.showInputDialog("How much would you like to withdraw: ");
				int withdraw_money = Integer.parseInt(withdraw);
				if (withdraw_money > acc_balance) {
					JOptionPane.showMessageDialog(null,"INSUFFICIENT FUNDS","ERROR", JOptionPane.ERROR_MESSAGE);
					End_balance = acc_balance;
				}
				else {
					End_balance = acc_balance - withdraw_money ;
				}
					break;
				
			case "d","D" :
				String deposit = JOptionPane.showInputDialog("How much would you like to deposit: ");
				int deposit_money = Integer.parseInt(deposit);
				if (deposit_money < 0) {
					JOptionPane.showMessageDialog(null,"INPUT A VALID AMOUNT ","ERROR", JOptionPane.ERROR_MESSAGE);
					End_balance = acc_balance;
				}
				else {
					 End_balance = acc_balance + deposit_money ;
				}
				
				break;	
			default:
	            System.out.println("Invalid choice");			
			}
			
			close = JOptionPane.showInputDialog("Would you like to perform another Transaction (Y/N) : ");
			
			if (close.equals ("N")|| close.equals ("n")){
				JOptionPane.showMessageDialog(null,"Thank you for using MiniATM, your reciept will be printed ","THANK YOU", JOptionPane.INFORMATION_MESSAGE);
				// Writing to the file
		        PrintWriter writer = new PrintWriter(new FileWriter("atm_receipt.txt"));

		        // Writing last four digits and account balance to the file
		        writer.println("Welcome to MiniATM!\n\n");
		        writer.println("Account Number (last 4): " + lastFourDigits+ "\n\n");
		        writer.println("Starting Balance: $" + acc_balance+ "\n\n");
		        writer.println("Ending Balance: $" + End_balance);

		        // Closing the writer 
		        writer.close();
			}
		}while(close.compareToIgnoreCase("N")!= 0);
		
		
		}
       // Function to check the lenght of the account number
	private static boolean hasEqualLength(int x , int y) {
		String strNum = String.valueOf(x);
        String stracc_num = String.valueOf(y);

        return strNum.length() == stracc_num.length();
	}
	
	

}
