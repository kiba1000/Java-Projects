/**
 * 
 */
/**
 * 
 */
module Lab05_AdejoMichael {
}