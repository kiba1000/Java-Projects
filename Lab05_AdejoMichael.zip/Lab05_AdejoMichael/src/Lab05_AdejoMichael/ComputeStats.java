/************
* Michael Adejo 
* Lab 05
* Febuary 18, 2024 
* A Program to Read data from a file and Write in a file
**/
package Lab05_AdejoMichael;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ComputeStats {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		//Declaring all Variables
		double value = 0;
		double sum = 0;
		int count = 0;
		double mean = 0;
		double stdDev = 0;
		double difference;
		Scanner keyboard = new Scanner (System.in);
		String filename;
		
		//Task 1
		System.out.println("THIS PROGRAM IS TO READ AND WRITE TO A FILE");
		System.out.println("*******************************************");
		
		System.out.println("Enter the filename to read: ");
		filename = keyboard.nextLine();
		
		// Create a Scanner object with the input file for the first pass
        Scanner inputFile = new Scanner(new File(filename));

        // First pass to calculate mean
        while (inputFile.hasNextDouble()) {
            double currentValue = inputFile.nextDouble();
            sum += currentValue;
            count++;
        }

        // Close the input file for the first pass
        inputFile.close();

        // Calculate mean
        if (count > 0) {
            mean = sum / count;
        }

        // Open the file for writing
        PrintWriter outputFile = new PrintWriter("Results.txt");

        // Print mean in 3 decimal places
        System.out.printf("Mean: %.3f\n", mean);
        outputFile.printf("Mean: %.3f\n", mean);

        // Reopen the file for the second pass
        inputFile = new Scanner(new File(filename));

        // Reinitialize sum and count for the second pass
        sum = 0;
        count = 0;

        // Second pass to calculate variance and standard deviation
        while (inputFile.hasNextDouble()) {
            value = inputFile.nextDouble();
            difference = value - mean;
            sum += Math.pow(difference, 2);
            count++;
        }

        // Close the input file for the second pass
        inputFile.close();

        // Calculate variance
        double variance = sum / count;

        // Calculate standard deviation
        stdDev = Math.sqrt(variance);

        // Print standard deviation in 3 decimal places
        System.out.printf("Standard Deviation: %.3f\n", stdDev);
        outputFile.printf("Standard Deviation: %.3f\n", stdDev);

        // Close the file and Scanner
        outputFile.close();
        keyboard.close();
	}

}
