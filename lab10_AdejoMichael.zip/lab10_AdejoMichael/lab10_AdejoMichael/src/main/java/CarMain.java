/**
* Michael Adejo 
* Lab 10
* April 07, 2024 
* This program is for Creating and Testing Car Functionality
*/

/**
 * The type Car main.
 */
public class CarMain {
    private static Car myCar;


    public static void main(String[] args) {
// Create a Car object
        myCar = new Car(2019, "Honda CRV", 11000, 100.0);

        // Test methods of the Car class
        System.out.println("Initial state:");
        System.out.println("Year: " + myCar.getYear());
        System.out.println("Model: " + myCar.getModel());
        System.out.println("Miles: " + myCar.getMiles());
        System.out.println("Fuel tank level: " + myCar.getFuelTankLevel() + "%");

        // Test drives method
        myCar.drives(150);

        // Test milesToFuelLevel method
        int miles = 300;
        myCar.modifyFuelTankLevel(miles);
        double fuelLevelPercentage = myCar.milesToFuelLevel();
        System.out.println("Fuel level percentage after " + miles + " miles: " + fuelLevelPercentage + "%");

        // Test modifyFuelTankLevel method
        System.out.println("Initial fuel tank level: " + myCar.getFuelTankLevel() + "%");
        myCar.modifyFuelTankLevel(200);
        System.out.println("Fuel tank level after modifying: " + myCar.getFuelTankLevel() + "%");
    }


}
