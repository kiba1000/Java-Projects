/**
* Michael Adejo 
* Lab 10
* April 07, 2024 
* This program is for Creating and Testing Car Functionality
*/
/**
 * The type Car.
 */
public class Car {
    private int year;
    private String model;
    private int miles;
    private double fuelLevel;

    /**
     * Instantiates a new Car.
     *
     * @param year      the year
     * @param model     the model
     * @param miles     the miles
     * @param fuelLevel the fuel level
     */
    public Car(int year, String model, int miles, double fuelLevel) {
        this.year = year;
        this.model = model;
        this.miles = miles;
        this.fuelLevel = fuelLevel;
    }

    /**
     * Gets year.
     *
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * Gets model.
     *
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * Gets miles.
     *
     * @return the miles
     */
    public int getMiles() {
        return miles;
    }

    /**
     * Gets fuel tank level.
     *
     * @return the fuel tank level
     */
    public double getFuelTankLevel() {
        return fuelLevel;
    }

    /**
     * Add miles.
     *
     * @param milesToAdd the miles to add
     */
    public void addMiles(int milesToAdd){
        this.miles += milesToAdd;
    }

    /**
     * Is fuel tank empty boolean.
     *
     * @return the boolean
     */
    public boolean isFuelTankEmpty(){
        return this.getFuelTankLevel() <= 0;
    }

    /**
     * Miles to fuel level double.
     *
     * @return the double
     */
    public  double milesToFuelLevel(){
// Calculate the fuel level percentage
        double fuelLevelPercentage = (miles / 400.0) * 100.0;

        // Ensure the fuel level percentage does not exceed 100%
        if (fuelLevelPercentage > 100.0) {
            fuelLevelPercentage = 100.0;
        }

        return fuelLevelPercentage;
    }

    /**
     * Modify fuel tank level.
     *
     * @param miles the miles
     */
    public void modifyFuelTankLevel(int miles){
        // Calculate fuel consumption based on miles traveled
        double fuelConsumed = miles / 400.0 * 100.0;

        // Check if fuel tank is not empty
        if (fuelLevel > 0) {
            // Adjust fuel tank level
            fuelLevel -= fuelConsumed;

            // Ensure fuel tank level is not negative
            if (fuelLevel < 0) {
                fuelLevel = 0;
            }
        }
    }

    /**
     * Drives.
     *
     * @param miles the miles
     */
    public void drives(int miles){
        // Check if the fuel tank is empty
        if (fuelLevel <= 0) {
            System.out.println("The " + year + " " + model + "'s fuel tank is empty!");
            return;
        }

        // Update total mileage
        this.miles += miles;

        // Calculate fuel consumed
        double fuelConsumed = miles / 400.0 * 100.0;

        // Adjust fuel tank level
        fuelLevel -= fuelConsumed;
        if (fuelLevel < 0) {
            fuelLevel = 0;
        }

        // Output the result
        System.out.println("The " + year + " " + model + " drove " + miles + " miles, for a total mileage of " +
                this.miles + " and a fuel tank level of " + fuelLevel + "%");
    }
}
