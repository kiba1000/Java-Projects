/************
* Michael Adejo 
* Lab 02 
* January 28, 2024 
* A program that Calculate the Volume of a sphere
**/
package Lab02_AdejoMichael;
import java.util.Scanner;
public class MathFunctions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create a Scanner Object to read input from the console
		Scanner keyboardInput = new Scanner(System.in);
		
		// Prompt the user to enter the diameter of the sphere
		System.out.print("Please enter the diameter of the sphere:");
		double diameter = keyboardInput.nextDouble();
		
		double radius= diameter/2;
		
		//Displays the diameter the user and the calculated radius
		System.out.println("You entered diameter:" + diameter);
		System.out.println("Therefore, Radius = " + radius );
		
		//Calculate the volume of the sphere
		double volume= (4.0/3.0)*Math.PI* Math.pow(radius, 3);
		
		
		//Display the result
		System.out.print("The volume of the sphere is: " + volume + "\n");
		
		/******
		 * New Section Below
		 * 
		 * Fixing Logic Errors 
		 * 
		 */
		System.out.println();
		System.out.println("FIXING LOGIC ERRORS\n");
		
		final int NUMBER = 2 ;
		final int SCORE1 = 100;
		final int SCORE2 = 95;
		final int BOILING_IN_F = 212;
		int fToC;
		double average;
		String output;
		// Find an arithmetic average.
		//Error: no parenthesis in the sum of score 1 and score 2
		average = (SCORE1 + SCORE2) / NUMBER;
		output = SCORE1 + " and " + SCORE2 + " have an average of " + average;
		System.out.println(output);
		
		// Convert Fahrenheit temperature to Celsius.
		// Error: incorrect order of operation in the conversion
		fToC = (BOILING_IN_F - 32) * 5/9;
		output = BOILING_IN_F + " in Fahrenheit is " + fToC + " in Celsius.";
		System.out.println(output);
		System.out.println();
		
		/*** THE LOGIC ERRORS CORRECTED
		 * 1.The parentheses to indicate that score 1 and score 2 should be sumed first in the declaration of average
		 * 
		 * 2. Rerranges the order of operation in the coversion section.
		 */

		
	}

}
