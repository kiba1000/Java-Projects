/************
* Michael Adejo 
* Lab 04 
* Febuary 11, 2024 
* A Dice Silumation using loops 
**/
package Lab04_AdejoMichael;
import java.util.Random;
public class DiceSimulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int NUMBER = 10000;
		int die1Value;
		int die2Value;
		int count = 0;
		int snakeEyes = 0;
		int twos = 0;
		int threes = 0;
		int fours = 0;
		int fives = 0;
		int sixes = 0; 
		
		System.out.println(" DICE SIMULATION USING A WHILE LOOP ");
		System.out.println("************************************");
	
		while(count < NUMBER )
		{
			Random dieNumber = new Random();
			// Generate a random number from 1 to 6 for each die
			die1Value = dieNumber.nextInt(6) + 1;
			die2Value = dieNumber.nextInt(6) + 1;
			
			// Check for specific conditions and increment counters
			if (die1Value == 1 && die2Value == 1) {
				snakeEyes++;
				
			}
			else if (die1Value == 2 && die2Value == 2) {
					twos++;
					
			}
			else if (die1Value == 3 && die2Value == 3) {
				threes++;
				
			}
			else if (die1Value == 4 && die2Value == 4) {
				fours++;
				
			}	
			else if (die1Value == 5 && die2Value == 5) {
				fives++;
				
			}
			else if (die1Value == 6 && die2Value == 6) {
				sixes++;
				
			}
			count++;
		}
		
		// Print the results
		System.out.println ("You rolled snake eyes " +
				snakeEyes + " out of " +
				count + " rolls.");
		System.out.println ("You rolled twos " +
				twos + " out of " +
				count + " rolls.");
		System.out.println ("You rolled threes " +
				threes + " out of " +
				count + " rolls.");
		System.out.println ("You rolled fours " +
				fours + " out of " +
				count + " rolls.");
		System.out.println ("You rolled fives " +
				fives + " out of " +
				count + " rolls.");
		System.out.println ("You rolled sixes " +
				sixes + " out of " +
				count + " rolls." + "\n");
		
		System.out.println(" DICE SIMULATION USING A Do-WHILE LOOP ");
		System.out.println("************************************");
		
		
		
		do {
			Random dieNumber = new Random();
			// Generate a random number from 1 to 6 for each die
			die1Value = dieNumber.nextInt(6) + 1;
			die2Value = dieNumber.nextInt(6) + 1;
			
			// Check for specific conditions and increment counters
			if (die1Value == 1 && die2Value == 1) {
				snakeEyes++;
				
			}
			else if (die1Value == 2 && die2Value == 2) {
					twos++;
					
			}
			else if (die1Value == 3 && die2Value == 3) {
				threes++;
				
			}
			else if (die1Value == 4 && die2Value == 4) {
				fours++;
				
			}	
			else if (die1Value == 5 && die2Value == 5) {
				fives++;
				
			}
			else if (die1Value == 6 && die2Value == 6) {
				sixes++;
				
			}
			count++;
		}
		while(count < NUMBER);
		
		//Print the results
		System.out.println ("You rolled snake eyes " +
				snakeEyes + " out of " +
				count + " rolls.");
		System.out.println ("You rolled twos " +
				twos + " out of " +
				count + " rolls.");
		System.out.println ("You rolled threes " +
				threes + " out of " +
				count + " rolls.");
		System.out.println ("You rolled fours " +
				fours + " out of " +
				count + " rolls.");
		System.out.println ("You rolled fives " +
				fives + " out of " +
				count + " rolls.");
		System.out.println ("You rolled sixes " +
				sixes + " out of " +
				count + " rolls." + "\n");
		
		System.out.println(" DICE SIMULATION USING A FOR LOOP ");
		System.out.println("**********************************");
		
			
		for(count = 0; count < NUMBER ; count++ )
		{
			// Generate a random number from 1 to 6 for each die
			die1Value = (int) (Math.random() * 6) +1;
			die2Value = (int) (Math.random() * 6) +1;
			
			// Check for specific conditions and increment counters
			if (die1Value == 1 && die2Value == 1) {
				snakeEyes++;
				
			}
			else if (die1Value == 2 && die2Value == 2) {
					twos++;
					
			}
			else if (die1Value == 3 && die2Value == 3) {
				threes++;
				
			}
			else if (die1Value == 4 && die2Value == 4) {
				fours++;
				
			}	
			else if (die1Value == 5 && die2Value == 5) {
				fives++;
				
			}
			else if (die1Value == 6 && die2Value == 6) {
				sixes++;
				
			}
			
		}
		
		//Print the results
		System.out.println ("You rolled snake eyes " +
				snakeEyes + " out of " +
				count + " rolls.");
		System.out.println ("You rolled twos " +
				twos + " out of " +
				count + " rolls.");
		System.out.println ("You rolled threes " +
				threes + " out of " +
				count + " rolls.");
		System.out.println ("You rolled fours " +
				fours + " out of " +
				count + " rolls.");
		System.out.println ("You rolled fives " +
				fives + " out of " +
				count + " rolls.");
		System.out.println ("You rolled sixes " +
				sixes + " out of " +
				count + " rolls.");
	
	}

}
