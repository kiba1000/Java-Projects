package lab12_AdejoMichael;

/**
 * The type Credit card.
 */
public class CreditCard {
    private Money balance;
    private final Money creditLimit;
    /**
     * The Owner.
     */
    Person owner;


    /**
     * Instantiates a new Credit card.
     *
     * @param newCardHolder the new card holder
     * @param limit         the limit
     */
    public CreditCard(Person newCardHolder, Money limit) {
        this.owner = newCardHolder;
        this.creditLimit = limit;
        balance = new Money(0);
    }

    /**
     * Gets  the credit balance.
     *
     * @return the balance
     */
    public Money getBalance() {
        return new Money(balance);
    }

    /**
     * Gets credit limit.
     *
     * @return the credit limit
     */
    public Money getCreditLimit() {
        return new Money(creditLimit);
    }

    /**
     * Get owner details string.
     *
     * @return the string
     */
    public String getPersonals(){
        return owner.toString();
    }

    /**
     * Charges a specified amount to the credit balance if the amount
     * does not exceed the credit limit.
     *
     * @param amount the amount
     */
    public void charge(Money amount){
        Money temp = new Money(balance);
        temp = temp.add(amount);
        if (temp.compareTo(creditLimit) < 0 ){
            balance = balance.add(temp);
        } else {
            System.out.println("Insufficient credit");
        }
    }

    /**
     * Payment.
     *
     * @param amount the amount
     */
    public void payment(Money amount){
        balance = balance.subtract(amount);
    }
}
