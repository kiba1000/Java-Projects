/**
* Michael Adejo 
* Lab 08 
* March 24, 2024 
* This program demonstrates static methods
*/
package lab08_methods;

import java.util.Scanner;

public class Geometry {
	public static void main(String[] args)
	{
		int choice;       // The user's choice
		double value = 0; // The method's return value
		char letter;
		double radius;
		double length;
		double width;
		double height;
		double base;
		double side1;
		double side2;
		double side3;
		// The user's Y or N decision
		// The radius of the circle
		// The length of the rectangle
		// The width of the rectangle
		// The height of the triangle
		// The base of the triangle
		// The first side of the triangle
		// The second side of the triangle
		// The third side of the triangle
		// Create a scanner object to read from the keyboard
		Scanner keyboard = new Scanner(System.in);
		// The do loop allows the menu to be displayed first
		do
		{
			// TASK #1 Call the printMenu method
			printMenu();
			
			choice = keyboard.nextInt();
			switch (choice)
			{
			case 1:
				System.out.print("Enter the radius of " +
						"the circle: ");
				radius = keyboard.nextDouble();
				// TASK #3 Call the circleArea method and
				// store the result in the value variable
				value = circleArea(radius);
				
				System.out.println("The area of the " +
						"circle is " + value);
				break;
			case 2:
				System.out.print("Enter the length of " +
						"the rectangle: ");
				length = keyboard.nextDouble();
				System.out.print("Enter the width of " +
						"the rectangle: ");
				width = keyboard.nextDouble();
				// TASK #3 Call the rectangleArea method and
				// store the result in the value variable
				value = rectangleArea(length,width);
				
				System.out.println("The area of the " +
						"rectangle is " + value);
				break;
			case 3:
				System.out.print("Enter the height of " +
						"the triangle: ");
				height = keyboard.nextDouble();
				System.out.print("Enter the base of " +
						"the triangle: ");
				base = keyboard.nextDouble();
				// TASK #3 Call the triangleArea method and
				// store the result in the value variable
				value = triangleArea(base,height);
				
				System.out.println("The area of the " +
						"triangle is " + value);
				break;
			case 4:
				System.out.print("Enter the radius of " +
						"the circle: ");
				radius = keyboard.nextDouble();
				// TASK #3 Call the circumference method and
				// store the result in the value variable
				value = circleCircumference(radius);
				
				System.out.println("The circumference " +
						"of the circle is " +
						value);
				break;
			case 5:
				System.out.print("Enter the length of " +
						"the rectangle: ");
				length = keyboard.nextDouble();
				System.out.print("Enter the width of " +
						"the rectangle: ");
				width = keyboard.nextDouble();
				// TASK #3 Call the perimeter method and
				// store the result in the value variable
				value = rectanglePerimeter(length,width);
				
				System.out.println("The perimeter of " +
						"the rectangle is " +
						value);
				break;
			case 6:
				System.out.print("Enter the length of " +
						"side 1 of the " +
						"triangle: ");
				side1 = keyboard.nextDouble();
				System.out.print("Enter the length of " +
						"side 2 of the " +
						"triangle: ");
				side2 = keyboard.nextDouble();
				System.out.print("Enter the length of " +
						"side 3 of the " +
						"triangle: ");
				side3 = keyboard.nextDouble();
				// TASK #3 Call the perimeter method and
				// store the result in the value variable
				value = trianglePerimeter(side1,side2,side3);
				
				System.out.println("The perimeter of " +
						"the triangle is " +
						value);
				break;
			default:
				System.out.println("You did not enter " +
						"a valid choice.");
			}
			keyboard.nextLine(); // Consume the new line
			System.out.println("Do you want to exit " +
					"the program (Y/N)?: ");
			String answer = keyboard.nextLine();
			letter = answer.charAt(0);
		} while(letter != 'Y' && letter != 'y');
		
		keyboard.close();
	}
	// TASK #1 Create the printMenu method here
	public static void printMenu() {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("This is a geometry calculator");
        System.out.println("Choose what you would like to calculate");
        System.out.println("1. Find the area of a circle");
        System.out.println("2. Find the area of a rectangle");
        System.out.println("3. Find the area of a triangle");
        System.out.println("4. Find the circumference of a circle");
        System.out.println("5. Find the perimeter of a rectangle");
        System.out.println("6. Find the perimeter of a triangle");

        System.out.print("Enter the number of your choice: ");
        
		int choice = keyboard.nextInt();

	}
	// TASK #2 Create the value-returning methods here
	
	/**
	 * Calculates the area of a circle.
	 * 
	 * This method requires the radius of the circle as input and calculates its area.
	 * 
	 * @param radius the radius of the circle
	 *        - Specifies the distance from the center of the circle to any point on its circumference.
	 * 
	 * @return the area of the circle
	 *         - Returns the calculated area of the circle as a double value.
	 */
	public static double circleArea(double radius) {
		double area = Math.PI * radius * radius ;
		return area;
		
	}
	/**
	 * Calculates the area of a rectangle.
	 * 
	 * This method requires the length and width of the rectangle as input and calculates its area.
	 * 
	 * @param length the length of the rectangle
	 *        - Specifies the distance between the two longer sides of the rectangle.
	 * @param width the width of the rectangle
	 *        - Specifies the distance between the two shorter sides of the rectangle.
	 * 
	 * @return the area of the rectangle
	 *         - Returns the calculated area of the rectangle as a double value.
	 */
	public static double rectangleArea(double length , double width) {
		double area = length * width ;
		return area;
		
	}
	/**
	 * Calculates the area of a triangle.
	 * 
	 * This method requires the base and height of the triangle as input and calculates its area.
	 * 
	 * @param base the base of the triangle
	 *        - Specifies the length of the bottom side of the triangle.
	 * @param height the height of the triangle
	 *        - Specifies the perpendicular distance from the base to the opposite vertex of the triangle.
	 * 
	 * @return the area of the triangle
	 *         - Returns the calculated area of the triangle as a double value.
	 */
	public static double triangleArea(double base , double height) {
		double area = (base * height)/ 2 ;
		return area;
		
	}
	/**
	 * Calculates the circumference of a circle.
	 * 
	 * This method requires the radius of the circle as input and calculates its circumference.
	 * 
	 * @param radius the radius of the circle
	 *        - Specifies the distance from the center of the circle to any point on its circumference.
	 * 
	 * @return the circumference of the circle
	 *         - Returns the calculated circumference of the circle as a double value.
	 */
	public static double circleCircumference(double radius) {
		double circumference = 2 * Math.PI * radius;
		return circumference;
		
	}
	/**
	 * Calculates the perimeter of a rectangle.
	 * 
	 * This method requires the length and width of the rectangle as input and calculates its perimeter.
	 * 
	 * @param length the length of the rectangle
	 *        - Specifies the distance between the two longer sides of the rectangle.
	 * @param width the width of the rectangle
	 *        - Specifies the distance between the two shorter sides of the rectangle.
	 * 
	 * @return the perimeter of the rectangle
	 *         - Returns the calculated perimeter of the rectangle as a double value.
	 */
	public static double rectanglePerimeter(double length , double width) {
		double perimeter = (2 * length) + (2 * width) ;
		return perimeter;
		
	}
	/**
	 * Calculates the perimeter of a triangle.
	 * 
	 * This method requires the lengths of the three sides of the triangle as input and calculates its perimeter.
	 * 
	 * @param side1 the length of side 1 of the triangle
	 *        - Specifies the length of one side of the triangle.
	 * @param side2 the length of side 2 of the triangle
	 *        - Specifies the length of another side of the triangle.
	 * @param side3 the length of side 3 of the triangle
	 *        - Specifies the length of the remaining side of the triangle.
	 * 
	 * @return the perimeter of the triangle
	 *         - Returns the calculated perimeter of the triangle as a double value.
	 */
	public static double trianglePerimeter(double side1 ,double side2 , double side3) {
		double perimeter = side1 + side2 + side3 ;
		return perimeter;
		
	}
	
	/**
	 * SAMPLE DATA and RESULT
	 * 1.) radius = 7 ; Result(Area) = 153.93804...
	 * 2.) length = 5, width = 4 ; result(Area) = 20
	 * 3.) base = 6, height = 4 ; reult(Area) = 12
	 * 4.) radius = 9 ; Result(circumference) = 56.54806...
	 * 5.) length = 6.5, width = 2 ; result(Perimeter) = 17
	 * 6.) side1 = 5, side2 = 3.4, side3 = 7 ; result(Perimeter)= 15.4
	 */
}