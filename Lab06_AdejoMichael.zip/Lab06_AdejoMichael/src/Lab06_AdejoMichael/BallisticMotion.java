/************
* Michael Adejo 
* Lab 06
* Febuary 25, 2024 
* Pragram to calculate ballistic trajectories and display using GUI
**/
package Lab06_AdejoMichael;

import javax.swing.JOptionPane;

public class BallisticMotion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Declaring All variables
		final double GRAVITATION = 9.81;
		double launchAngle = 0.0;
		double initialVelocity = 0.0;
		double flightTime = 0.0;
		double maxDistance = 0.0;
		
		// A Welcome information dialog box
		JOptionPane.showMessageDialog(null,"Calculating Ballistic Trajectories", "WELCOME", JOptionPane.INFORMATION_MESSAGE);
		
		//A dialog box to prompt instructions
		JOptionPane.showMessageDialog(null,"On the next screens,please input a launch angle and an initial velocity.","Ballistic Trajectories", JOptionPane.INFORMATION_MESSAGE);
		
		//Promplt the user to input the launch Angle
		String launchAngleInput = JOptionPane.showInputDialog("What is the Launch Angle: ");
		//Parse the string lauchAngle to a double
		launchAngle = Double.parseDouble(launchAngleInput);
		
		//Promplt the user to input the Initial Velocity
		String initialVelocityInput = JOptionPane.showInputDialog("What is the Initial Velocity: ");
		//Parse the string initialVelocity to a double
		initialVelocity = Double.parseDouble(initialVelocityInput);
		
		//compresing the terms to single characters
		double v = initialVelocity; 
        double r = Math.toRadians(launchAngle); 
        double g = GRAVITATION;
        
        //Formula calculation for flight time
        flightTime = (2 * v * Math.sin(r)) / g;
        
        //Rounding the flightTime to 3 decimal places
        flightTime = Math.round(flightTime * 1000.0) / 1000.0;
        
        //Dialog box to display calculated flightTime
        JOptionPane.showMessageDialog(null,"Flight Time = " + flightTime , "Flight Time", JOptionPane.INFORMATION_MESSAGE);
        
        //Formula calculation for Maximum Distance
        maxDistance = (v * Math.cos(r)) * flightTime;
        
        //Rounding the maxDistance to 3 decimal places
        maxDistance = Math.round(maxDistance * 1000.0) / 1000.0;
        
        //Dialog box to display maxDistance 
        JOptionPane.showMessageDialog(null,"Maximum Distance = " + maxDistance , "Distance Traveled", JOptionPane.INFORMATION_MESSAGE);
        
        
	}

}
