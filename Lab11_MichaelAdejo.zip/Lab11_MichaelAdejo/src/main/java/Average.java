/***
 * Michael adejo
 * Lab 11
 * April 14, 2024
 * implementation of arrays
 */
import java.util.Arrays;
import java.util.Scanner;

public class Average {
    private int[] data;
    private double mean;

    public Average() {
        data = new int[5];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < data.length; i++) {
            System.out.print("Enter score number " + (i + 1) + ": ");
            data[i] = scanner.nextInt();
        }
        scanner.close();
        calculateMean();
        selectionSort();

    }

    public void calculateMean(){
        int sum = 0;
        for( int num : this.data) sum += num;
        mean = sum / this.data.length;
    }


    @Override
    public String toString() {
        return "Average{" +
                "data=" + Arrays.toString(data) +
                ", mean=" + mean +
                '}';
    }

    private void selectionSort() {
        for (int i = 0; i < data.length - 1; i++) {
            int maxIndex = i;
            for (int j = i + 1; j < data.length; j++) {
                if (data[j] > data[maxIndex]) {
                    maxIndex = j;
                }
            }
            // Swap elements
            int tempArray = data[i];
            data[i] = data[maxIndex];
            data[maxIndex] = tempArray;
        }
    }
}
