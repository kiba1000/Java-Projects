public class AverageDriver {
    public static void main(String[] args) {
        Average sample = new Average();
        System.out.println(sample);
    }
}
